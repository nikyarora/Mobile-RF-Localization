Todo
===========

Add SPI support

Verify wiring and library with Logic Analyser

Add documentation about what each function actually does

Add address pin select for I2C upon startup