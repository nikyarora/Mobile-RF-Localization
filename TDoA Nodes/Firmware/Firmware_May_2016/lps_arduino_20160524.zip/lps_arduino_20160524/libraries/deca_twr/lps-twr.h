#ifndef _LPS_TWR_H
#define _LPS_TWR_H

#if ARDUINO < 100
#include <WProgram.h>
#else  // ARDUINO
#include <Arduino.h>
#endif  // ARDUINO

#include <deca_device_api.h>
#include <deca_twr.h>
#include <deca_spi.h>

#include <lps.h>

namespace LPS
{
    uint32 initDWRanging(int instance_mode, uint8 instance_addr)
    {
        uint32 devID ;
        instanceConfig_t instConfig;
        int result;

        openspi();
        spi_setSpeedSlow();

        // reset the DW1000
        LPS::reset_DW1000();

#ifdef ARDUINO_ESP8266_ESP12E
        dwt_setspilaunchedge(1);
#endif
        devID = instancereaddeviceid() ;
        if(DWT_DEVICE_ID != devID) 
        {
            // Failed to read Decaid
            return(-1) ;
        }

        result = instance_init( ) ;
        if (0 > result) return(-1) ; // Some failure has occurred

        spi_setSpeedFast();

        instancesetrole(instance_mode) ;     // Set this instance role
        instance_init_s(instance_mode);

        // Channel and parameter settings
        instConfig.channelNumber = 5;
        instConfig.preambleCode = 3;
        instConfig.pulseRepFreq = DWT_PRF_16M;
        instConfig.pacSize = DWT_PAC32;
        instConfig.nsSFD = 1;
#ifndef LPS_FAST_RANGING
        instConfig.sfdTO = (1025 + 64 - 32);
        instConfig.dataRate = DWT_BR_110K;
        instConfig.preambleLen = DWT_PLEN_1024;
#else
        instConfig.sfdTO = (256 + 64 - 32);
        instConfig.dataRate = DWT_BR_6M8;
        instConfig.preambleLen = DWT_PLEN_256;
#endif

        // Set operating channel etc
        instance_config_nootp(&instConfig) ;                  

        //instancesetantennadelays(514.9067);
        instancesetantennadelays_i(0x4012); // Equals 514.9067

        // Setup initial Payload configuration
        instanceAddressConfig_t ipc ;
        ipc.forwardToFRAddress = 0xDECA020000000001;
        ipc.tagAddress = 0xDECA010000000000 | instance_addr;
        ipc.anchorAddress = 0xDECA020000000000;
        ipc.anchorAddress |= instance_addr;
        ipc.anchorListSize = ANCHOR_LIST_SIZE ;

        ipc.sendReport = 1 ;  //1 => anchor sends TOF report to tag

        // The poll mask decides which of the anchors the tag polls to start ranging with.
        // The fewer number of anchors a tag has to scan in each cycle the faster the cycles
        // A mask of 0xff will poll anchors 0-7, 0xf polls anchors 0-3 and 0xf0 anchors 4-7. 

        //ipc.anchorPollMask = (uint64_t)0xffff; // anchor poll mask - polling anchors 0-19
        ipc.anchorPollMask = (uint64_t)0x3ff;    // anchor poll mask - polling anchors 0-9

        instancesetaddresses(&ipc);

        // The sleep delays is how long the tag will sleep inbetween ranging cycles. 
        // This is normally set to around 50-100ms for the LPS and 200+ for LPSmini
#ifdef LPS_DEMO
        // Note that a sleep time that is too short (<50?) will cause LPS to hang, most 
        // likely because it's alarm goes off before it get's properly tucked into sleep. 
        // (the real reason why has not been investigated entirely yet)
        // The blink delay is not really relevant in the current mode but kept here for legacy.
    #if defined(LPSMINI_V10)
        instancesettagsleepdelay(POLL_SLEEP_DELAY, BLINK_SLEEP_DELAY); //set the Tag sleep time
    #else
        instancesettagsleepdelay(POLL_SLEEP_DELAY, BLINK_SLEEP_DELAY); //set the Tag sleep time
    #endif

#else
        instancesettagsleepdelay(0, 0); //set the Tag sleep time
#endif

        //this is for ARM to ARM tag/anchor (using normal response times 10ms)
        instancesetblinkreplydelay(FIXED_REPLY_DELAY);

        //set the default response delays
        instancesetreplydelay(FIXED_REPLY_DELAY, 0);

        return devID;
    }
        
} // namespace LPS

#endif
