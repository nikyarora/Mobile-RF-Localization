#ifndef _PORT_H_
#define _PORT_H_

#define port_DisableEXT_IRQ cli
#define port_EnableEXT_IRQ sei


#endif
