#ifndef _LPS_TREK_H
#define _LPS_TREK_H

#include <deca_device_api.h>
#include <deca_regs.h>
#include <deca_trek.h>
#include <deca_spi.h>

#include <lps.h>


// TREK1000
#define SWS1_SHF_MODE 0x02	//short frame mode (6.81M)
#define SWS1_CH5_MODE 0x04	//channel 5 mode
#define SWS1_ANC_MODE 0x08  //anchor mode
#define SWS1_A1A_MODE 0x10  //anchor/tag address A1
#define SWS1_A2A_MODE 0x20  //anchor/tag address A2
#define SWS1_A3A_MODE 0x40  //anchor/tag address A3
typedef struct
{
    uint8 channel ;
    uint8 prf ;
    uint8 datarate ;
    uint8 preambleCode ;
    uint8 preambleLength ;
    uint8 pacSize ;
    uint8 nsSFD ;
    uint16 sfdTO ;
} chConfig_t;


namespace LPS
{    
    //Slot and Superframe Configuration for DecaRangeRTLS TREK Modes (4 default use cases selected by the switch S1 [2,3] on EVB1000, indexed 0 to 3 )
    const sfConfig_t sfConfig[4] ={
        //mode 1 - S1: 2 off, 3 off
        {
            (28), //ms -
            (10),   //thus 10 slots - thus 280ms superframe means 3.57 Hz location rate (10 slots are needed as AtoA ranging takes 30+ ms)
            (10*28), //superframe period
            (10*28), //poll sleep delay
            (20000) // normally 20000
        },
        //mode 2 - S1: 2 on, 3 off
        {
            (10),   // slot period ms
            (10),   // number of slots (only 10 are used) - thus 100 ms superframe means 10 Hz location rate
            (10*10), // superframe period (100 ms - gives 10 Hz)
            (10*10), // poll sleep delay (tag sleep time, usually = superframe period)
            (2500)
        },
        //mode 3 - S1: 2 off, 3 on
        {
            (28),    // slot period ms
            (10),     // thus 10 slots - thus 280ms superframe means 3.57 Hz location rate
            (10*28),  // superframe period
            (10*28),  // poll sleep delay
            (20000)
        },
        //mode 4 - S1: 2 on, 3 on
        {
            (10),   // slot period ms
            (10),   // number of slots (only 10 are used) - thus 100 ms superframe means 10 Hz location rate
            (10*10), // superframe period (100 ms - gives 10 Hz)
            (10*10), // poll sleep (tag sleep time, usually = superframe period)
            (2500) // this is the Poll to Final delay - 2ms (NOTE: if using 6.81 so only 1 frame per ms allowed LDC)
        }
    };


    uint8_t initTREKTag(uint8 dipaddress)
    {
        instanceConfig_t instConfig;
        int result;

        openspi();
        spi_setSpeedSlow();

        // reset the DW1000
        LPS::reset_DW1000();

#ifdef ARDUINO_ESP8266_ESP12E
        dwt_setspilaunchedge(1);
#endif
        uint32_t devID = instancereaddeviceid() ;
        if(DWT_DEVICE_ID != devID) 
        {
            Serial.println(F("DWM failed"));
            return 0;
        }

        result = instance_init() ;
        if (!result) return 0; // Some failure has occurred
        dwt_setcallbacks(trek1000::instance_txcallback, trek1000::instance_rxcallback_tag);

        spi_setSpeedFast();

        //instancesetantennadelays(514.9067);
        instancesetantennadelays_i(0x4042); // Equals 514.9067

        uint16_t addr = (((dipaddress & SWS1_A1A_MODE) << 2) + (dipaddress & SWS1_A2A_MODE) + ((dipaddress & SWS1_A3A_MODE) >> 2)) >> 4;
        instancesetaddresses(addr);
        instancesetrole(TAG);

        // Channel and parameter settings
        const chConfig_t chConfig[4] ={
            //mode 1 - S1: 2 off, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                4,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 2 - S1: 2 on, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                4,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            },
            //mode 3 - S1: 2 off, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                3,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 4 - S1: 2 on, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                3,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            }
        };

        uint8 dr_mode = 0;

        if(dipaddress & SWS1_SHF_MODE) dr_mode = 1;
        if(dipaddress & SWS1_CH5_MODE) dr_mode+= 2;

        instConfig.channelNumber = chConfig[dr_mode].channel ;
        instConfig.preambleCode = chConfig[dr_mode].preambleCode ;
        instConfig.pulseRepFreq = chConfig[dr_mode].prf ;
        instConfig.pacSize = chConfig[dr_mode].pacSize ;
        instConfig.nsSFD = chConfig[dr_mode].nsSFD ;
        instConfig.sfdTO = chConfig[dr_mode].sfdTO ;
        instConfig.dataRate = chConfig[dr_mode].datarate ;
        instConfig.preambleLen = chConfig[dr_mode].preambleLength ;

        instance_config_nootp(&instConfig, &sfConfig[dr_mode]) ;                  // Set operating channel etc

        return 1;
    }

    uint8_t initTREK(uint8 dipaddress)
    {
        instanceConfig_t instConfig;
        int result;

        openspi();
        spi_setSpeedSlow();

        // reset the DW1000
        LPS::reset_DW1000();
        dwt_setspilaunchedge(1);

        uint32_t devID = instancereaddeviceid() ;
        if(DWT_DEVICE_ID != devID) 
        {
            Serial.println(F("DWM failed"));
            return 0;
        }

        result = instance_init() ;
        if (!result) return 0; // Some failure has occurred
        dwt_setcallbacks(trek1000::instance_txcallback, trek1000::instance_rxcallback_all);

        spi_setSpeedFast();

        //instancesetantennadelays(514.9067);
        instancesetantennadelays_i(0x4042); // Equals 514.9067

        uint16_t addr = (((dipaddress & SWS1_A1A_MODE) << 2) + (dipaddress & SWS1_A2A_MODE) + ((dipaddress & SWS1_A3A_MODE) >> 2)) >> 4;
        instancesetaddresses(addr);
        instancesetrole((dipaddress & SWS1_ANC_MODE) ? ANCHOR : TAG);

        // Channel and parameter settings
        const chConfig_t chConfig[4] ={
            //mode 1 - S1: 2 off, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                4,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 2 - S1: 2 on, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                4,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            },
            //mode 3 - S1: 2 off, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                3,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 4 - S1: 2 on, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                3,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            }
        };

        uint8 dr_mode = 0;

        if(dipaddress & SWS1_SHF_MODE) dr_mode = 1;
        if(dipaddress & SWS1_CH5_MODE) dr_mode+= 2;

        instConfig.channelNumber = chConfig[dr_mode].channel ;
        instConfig.preambleCode = chConfig[dr_mode].preambleCode ;
        instConfig.pulseRepFreq = chConfig[dr_mode].prf ;
        instConfig.pacSize = chConfig[dr_mode].pacSize ;
        instConfig.nsSFD = chConfig[dr_mode].nsSFD ;
        instConfig.sfdTO = chConfig[dr_mode].sfdTO ;
        instConfig.dataRate = chConfig[dr_mode].datarate ;
        instConfig.preambleLen = chConfig[dr_mode].preambleLength ;

        instance_config_nootp(&instConfig, &sfConfig[dr_mode]) ;                  // Set operating channel etc

        return 1;
    }


    uint8_t initTREKListener(uint8 dipaddress)
    {
        int result;

        openspi();
        spi_setSpeedSlow();

        // reset the DW1000
        LPS::reset_DW1000();

        dwt_setspilaunchedge(1);
        spi_setSpeedFast();

        uint16_t addr = (((dipaddress & SWS1_A1A_MODE) << 2) + (dipaddress & SWS1_A2A_MODE) + ((dipaddress & SWS1_A3A_MODE) >> 2)) >> 4;

        // Channel and parameter settings
        const chConfig_t chConfig[4] ={
            //mode 1 - S1: 2 off, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                4,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 2 - S1: 2 on, 3 off
            {
                2,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                4,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            },
            //mode 3 - S1: 2 off, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_110K,    // datarate
                3,              // preambleCode
                DWT_PLEN_1024,  // preambleLength
                DWT_PAC32,      // pacSize
                1,       // non-standard SFD
                (1025 + 64 - 32) //SFD timeout
            },
            //mode 4 - S1: 2 on, 3 on
            {
                5,              // channel
                DWT_PRF_16M,    // prf
                DWT_BR_6M8,    // datarate
                3,             // preambleCode
                DWT_PLEN_128,   // preambleLength
                DWT_PAC8,       // pacSize
                0,       // non-standard SFD
                (129 + 8 - 8) //SFD timeout
            }
        };

        uint8 dr_mode = 0;

        if(dipaddress & SWS1_SHF_MODE) dr_mode = 1;
        if(dipaddress & SWS1_CH5_MODE) dr_mode+= 2;
        Serial.print(F("dr_mode:"));Serial.println(dr_mode);

        dwt_config_t cfg;

        cfg.chan = chConfig[dr_mode].channel ;
        cfg.rxCode = chConfig[dr_mode].preambleCode ;
        cfg.txCode = chConfig[dr_mode].preambleCode ;
        cfg.prf = chConfig[dr_mode].prf ;
        cfg.dataRate = chConfig[dr_mode].datarate ;
        cfg.txPreambLength = chConfig[dr_mode].preambleLength ;
        cfg.rxPAC = chConfig[dr_mode].pacSize ;
        cfg.nsSFD = chConfig[dr_mode].nsSFD ;
        cfg.phrMode = DWT_PHRMODE_STD ;
        cfg.sfdTO = chConfig[dr_mode].sfdTO ;
        cfg.smartPowerEn = (cfg.dataRate==DWT_BR_6M8) ? 1 : 0;

        dwt_configure_nootp(&cfg);
        dwt_initialise(DWT_LOADUCODE | DWT_LOADLDOTUNE | DWT_LOADTXCONFIG | DWT_LOADANTDLY| DWT_LOADXTALTRIM) ;
        dwt_setsmarttxpower(cfg.smartPowerEn);

        dwt_txconfig_t configTX;
        if (cfg.chan == 2)
        {
            configTX.PGdly = 0xc2;
            configTX.power = 0x15355575; //txSpectrumConfig[config->channelNumber].txPwr[config->pulseRepFreq- DWT_PRF_16M];
        }
        else // Channel 5
        {
            configTX.PGdly = 0xc0;
            configTX.power = 0x0E082848; //txSpectrumConfig[config->channelNumber].txPwr[config->pulseRepFreq- DWT_PRF_16M];
        }
        dwt_configuretxrf(&configTX);
        dwt_setrxantennadelay(0x4042);
        dwt_settxantennadelay(0x4042);
        
        uint64_t r = 0xdeca;
        dwt_setpanid(r);
        dwt_seteui((uint8*)&r);

        return 1;
    }

} // namespace LPS

#endif
