#ifndef RANGEPACKET_H
#define RANGEPACKET_H

#include "Packet.h"
#include "Crc.h"

class RangePacket : public Packet
{
public:
    RangePacket( ) : Packet(PACKET_TYPE_RANGE, 0x0001, 0x0195), 
                     _anchorid(0), _distinmm(0), _power(0)
    {
        // Constructor
    }

    RangePacket(Packet &p) : Packet(p)
    {
        this->unPack();
    }

    void mx(int16_t d) {_mx = d;}
    void my(int16_t d) {_my = d;}
    void mz(int16_t d) {_mz = d;}

    void anchorid(uint16_t id) {_anchorid = id;}
    void distinmm(uint32_t d)  {_distinmm = d;}
    void power(float d)  {_power = floor(-d*10);}

protected:
    virtual void Pack(){
        _length = 14;
        uint8_t *p = _data;
        p += hton(_anchorid, p);
        p += hton(_distinmm, p);
        p += hton(_power, p);
        p += hton(_mx, p);
        p += hton(_my, p);
        p += hton(_mz, p);
    }

    virtual void unPack(){
        _anchorid = ntoh_u16(_data);
        _distinmm = ntoh_u32(_data+2);
        _power = ntoh_i16(_data+6);
        _mx = ntoh_i16(_data+8);
        _my = ntoh_i16(_data+10);
        _mz = ntoh_i16(_data+12);
    }

private:
    uint16_t _anchorid;
    uint32_t _distinmm;
    int16_t _power;
    int16_t _mx;
    int16_t _my;
    int16_t _mz;
};

#endif // RANGEPACKET_H
