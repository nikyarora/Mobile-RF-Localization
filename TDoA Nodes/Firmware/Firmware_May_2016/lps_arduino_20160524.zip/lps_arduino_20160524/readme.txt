LPS Demo firmware
=================
Loligo LPS example Arduino source code based on the Decawave two way ranging algorithm for the EVK.
All boards communicate at 115200bps (8-n-1).


Directory structure
===================
/libraries    - Dependancies and main libraries
/lps-main     - Main source for the LPS v1.1 board
/lpsmini-main - Main source for LPSMini v1.0
/simple_twr   - Demonstrating single sided TWR at 6M8 between two boards. See the Simple TWR example below.
/trek_tag     - Demonstrating acting as a TREK1000 tag (needs to be an LPS or LPSMini with 12MHz or faster crystal)
                Note that only 110k (and not 6M8) is supported at this stage. 
/trek_listener- Listens to trek communication (or any communication with the same settings) DIP for mode needs to
                match that of TREK1000 (datarate and channel).
/hardware     - Loligo LPS board definitions, to be installed in the arduino suite
/hexfiles     - Working builds of current source and bootloader
  --/lps_v11_demo_<date released>.hex              - LPS v1.0 Two way ranging demo firmware
  --/lps_v11_16MHz_optiboot_<date released>.hex    - LPS Bootloader for 16MHz board (Optiboot)
  --/lps_v11_20MHz_optiboot_<date released>.hex    - LPS Bootloader for 20MHz board (Optiboot)
  --/lps_v11_trektag_<date released>.hex           - LPS act as TAG in TREK1000
  --/lpsmini_v10_8m_demo_<date released>.hex       - LPSMini v1.0 Two way ranging demo firmware (8MHz boards)
  --/lpsmini_v10_12m_demo_<date released>.hex      - LPSMini v1.0 Two way ranging demo firmware (12MHz boards)
  --/lpsmini_v10_12m_imudmp_<date released>.hex    - LPSMini v1.0 IMU demo using mpu9250 internal Digital motion processor
  --/lpsmini_v10_12m_trektag_<date released>.hex   - LPSMini act as TAG in TREK1000 (only 12MHz supported)
  --/lpsmini_v10_8m_optiboot_<date released>.hex   - LPSMini Bootloader (Optiboot)
  --/lpsmini_v10_12m_optiboot_<date released>.hex  - LPSMini Bootloader (Optiboot)

For the LPSMini: 8m is for 8MHz boards and 12m for 12MHz boards.
Add the contents of the libraries folder to your arduino library path. 


DIP Switch on LPS
=================
In this demo software the dip is used both to select between TAG / ANCHOR mode and the address of the chip:

DIP 1-4 | Address of the board. 
DIP 5-7 | Unused
DIP 8   | ON - TAG | OFF - ANCHOR

For the TREK-tag firmware the DIP settings mirror those on the TREK1000 boards:

DIP 1   | unused
DIP 2   | ON - Channel 5 | OFF Channel 2
DIP 3   | ON - 6M8       | OFF 110k datarate
DIP 4


A note on update rate
=====================
A number of things affect the update rate. In order to get LPSMini more stable the poll rate was lowered from previous releases. 
This can easily be changed in libraries/deca_instance/lps.h on around line 160, search for 'instancesettagsleepdelay'. Lower the 
values of the sleep delays to increase the update rate. Either you can simply change the functions to run as:

instancesettagsleepdelay(50,50); 

or change the defined values in the Decawave instance header: deca_instance.h, look for 'POLL_SLEEP_DELAY'. 
Note that setting these values too low will cause the LPS to hang. Play around with them. 
Values around 50-100 should work well for LPS, and 200-300 for LPSmini. 
When not using the intertial measurements these values can be lower giving you a faster update rate. 

The second thing that will have an even greater impact depending on how many anchors you have is the poll mask. 
The poll mask decides which of the anchors the tag polls to start ranging with. The fewer number of anchors a tag 
has to scan in each cycle the faster the cycles. A mask of 0xff will poll anchors 0-7, 0xf polls anchors 0-3 and 0xf0 anchors 4-7. 
You find this in the same lps.h around line 150. If you only have 4 anchors set this value to 0x00f; That is, the 
first 4 bits are ones and make sure your anchors are configured as address 0-3.

Further, by default the LPS use 110k transfer rate to get long range (up to 300+m has been achieved in unobstructed areas). If
you change this to use the 6.8m transfer rate your ranging will be faster but the maximum range will be shorter. There is experimental
support for this by adding the #define LPS_FAST_RANGING to the top of your lps-main.ino or lpsmini-main.ino. Note that you have to
reprogram all your tags and anchors to use the same datarate. (NOTE-TO-SELF:this should be placed on a DIP setting)


Inertial Measurements
=====================
If you are not using the inertial measurements you can disable them. Look at the top of your lps-main.ino (or lpsmini-main.ino) 
for the #define LPS_V11_ACC or #define LPSMINI_ACC. Commenting these lines out will disable the inertial measurements and will
reduce the memory footprint. For example: 

Change:
#define LPS_V11_ACC

to

// #define LPS_V11_ACC

to disable the accelerometer for the LPS (not mini). Note that the current release has the mini intertial measurements disabled.
You can enable them by uncommenting the "#define LPS_V11_ACC" line. 


Programming the bootloader using avrdude
========================================
For LPS:
avrdude  -c stk500v2 -p atmega328p -P usb -b 115200 -e -u -U lock:w:0x3f:m -U efuse:w:0x05:m -U hfuse:w:0xDE:m -U lfuse:w:0xFF:m \
         -U flash:w:hexfiles/lps_v11_optiboot_<board speed and date released>.hex -U lock:w:0x2f:m

For LPSmini:
avrdude  -c stk500v2 -p atmega328p -P usb -b 115200 -e -u -U lock:w:0x3f:m -U efuse:w:0x05:m -U hfuse:w:0xDE:m -U lfuse:w:0xFF:m \
         -U flash:w:hexfiles/lpsmini_<board speed and date released>.hex -U lock:w:0x2f:m


Compiling and programming using the arduino suite
=================================================
Setup the board manager:
1. Under Preferences, Additional Board Managers URLs add: https://github.com/loligo/lps/raw/master/package_loligo_lps_index.json
2. Under Tools, Board, Boards Manager: install lps by Loligo
3. Select the correct LPS board under the Tools, Board menu
Make sure you set the correct serial port. Note that when using the serial monitor you need to select
115200 as your baudrate. 


Uploading hex files directly using the Chrome app AVRChick
==========================================================
In the chrome webstore there is an application called AVRChick. This can upload the hexfiles
provided to your LPS board. You need to connect your LPS board to the computer before starting
AVRChick as it does not refresh it's list of devices. This is a link to the Chrome webstore for
AVRChick:
https://chrome.google.com/webstore/detail/avrchick/kpbgbcocfgjbmnpplcjlcammjdkgogba?hl=en

Debugging
=========
Add the following variables to your preferences.txt: 
build.verbose=true
upload.verbose=true
(you'll find it by opening File/Preferences in the arduino suite, at the bottom: "More preferences can be edited directly in the file...")
I you have issues make sure to turn these on, copy the text output to a textfile and include this in your email for help. 


Simple TWR example
==================
This is a port of Decawave's own example of Single-sided two-way ranging (SS TWR). LPS board with address set to 0
will initate the ranging. If the address is set to something else it will reply to range requests. Extremely simple
and only works with two boards. The address can be set with DIPs 5-7 in the same way as TREK1000 configures the Tag/Anchor id.

