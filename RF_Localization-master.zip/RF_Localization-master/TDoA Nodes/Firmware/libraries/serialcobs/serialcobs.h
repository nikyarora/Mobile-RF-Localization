#ifndef SERIALCOBS_H
#define SERIALCOBS_H

#include "Packet.h"
#include "RangePacket.h"
#include "AccelerometerPacket.h"


#endif
