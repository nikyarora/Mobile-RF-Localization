import math



exp = (abs(8+-60)/20) - 1.26
print (pow(10.0, exp))

